PDLeft.xlsx and PDright.xlsx are raw data. MeanPD is pre-processed.

Interpolation was applied to remove zeros from eye blinks, then normalised 0-1 for each participant (across all of that participant's data), and then averaged. This produces a mean PD for each participant on each video (T1-T20,F1-F20). Then those are averaged for each video to produce the LeftPD and RightPD sheets in the MeanPD file.
